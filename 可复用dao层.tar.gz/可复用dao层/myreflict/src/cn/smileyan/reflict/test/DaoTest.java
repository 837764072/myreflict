package cn.smileyan.reflict.test;

import cn.smileyan.reflict.dao.UserDao;
import cn.smileyan.reflict.dao.impl.UserDaoImpl;
import cn.smileyan.reflict.domain.User;

/**
 * 专门用于测试dao层是否正常
 * @author root
 *
 */
public class DaoTest {
	
	public static void main(String[] args) {
		UserDao baseDao=new UserDaoImpl();//出错只在这行代码
		
		User user=new User();
		user.setEmail("email");
		user.setNickname("nickname");
		user.setPassword("password");
		user.setId(0);
		user.setUsername("username");
		
		baseDao.save(user);
		user.setId(1);
		baseDao.delelte(user);
		baseDao.update(user);
		baseDao.find(user);
		baseDao.getAll("where username=nice");
		baseDao.deleleteAll("where id<8");
	}
}
