package cn.smileyan.reflict.util;

import java.lang.reflect.Field;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

/**
 * 借用了Apache 的BeanUtils
 * 添加了自己的方法
 * @author root
 *
 */
public class MyBeanUtil<T> {
	/**
	 * 根据对象拿到对象的类的属性名，并且加入到链表中并返回
	 * @param t 
	 * @return list
	 */
	public List<String> getFieldName(T t){
		// 反射 拿到此对象的类
		Class<?> clazz = t.getClass();  
		Field[] fields = clazz.getDeclaredFields();
	    // 拿到所有的属性名
		int length = fields.length;
		List<String> all=new LinkedList<>();
		for(int i=0; i<length; i++) {
			all.add(fields[i].getName().toString());
		}
		return all;
	}
	
	/**
	 * 反射方法拿到id
	 * @param t
	 * @return id
	 */
	public int getId(T t) {
		int id=-1;
		try {
			id=Integer.parseInt(BeanUtils.getProperty(t, "id"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}
	
}
