package cn.smileyan.reflict.dao;

import cn.smileyan.reflict.domain.User;

public interface UserDao extends BaseDao<User>{
	
}
