package cn.smileyan.reflict.dao.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import cn.smileyan.reflict.dao.BaseDao;
import cn.smileyan.reflict.util.MyBeanUtil;
/**
 * 可复用DaoImpl
 * 只是生成sql语句，真正操作数据库需要在每个操作后面添加语句。
 * @author smileyan
 * 需要注意如下：
 * 1. deleleteAll(String param) 参数中需要保证sql规范性，比如 where username='nice' 而不能落掉单引号
 * 	  getAll(String param)  也是如此
 * 2. save方法返回的是新添对象的ID，添加失败返回-1
 * 	  update方法返回的是修改对象的ID，修改失败则返回-1
 *   `find方法是根据ID找具体对象，返回一个对象，未找到则返回null
 *    delete方法是根据ID删除对象.返回删除对象的ID，删除失败返回-1
 *    deleleteAll方法根据条件删除对象。返回删除对象的数量，删除失败返回-1，
 *    findAll方法根据条件返回对象，如果不存在返回null。
 * 最后修改：2018/6/28 
 * @param <T>
 */
public class BaseDaoImpl<T> implements BaseDao<T> {
	private Class<T> beanClass;
	
	@SuppressWarnings("unchecked")
	public BaseDaoImpl() {
		// 拿到泛型并初始化beanClass
		ParameterizedType parameterizedType=(ParameterizedType)this.getClass().getGenericSuperclass();
		beanClass = (Class<T>) parameterizedType.getActualTypeArguments()[0];
	}
	
	@Override
	public int save(T t) {
		// 1. 拿到类的所有属性的链表 和 类名
		List<String> allParam=new MyBeanUtil<T>().getFieldName(t);
		String className=t.getClass().getSimpleName();
		
		// 2. 处理所有的属性sql，为了节省开销，使用StringBuffer类
		StringBuffer sql = new StringBuffer("insert into "+className+"(");
		// 向其中插入所有属性，注意是按顺序插入
		short i;
		for (i=0; i<allParam.size()-1; i++) {
			sql.append((allParam.get(i)+","));
		}
		sql.append((allParam.get(i)+") values("));
		
		// 添加属性对应的数值
		for(i=0; i<allParam.size()-1; i++) {
			String value=null;
			try {
				value = BeanUtils.getProperty(t,allParam.get(i)).toString();
			} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
				e.printStackTrace();
			}
			sql.append(("'"+value+"',"));
		}
		
		// 添加最后一个属性
		String value=null;
		try {
			value = BeanUtils.getProperty(t,allParam.get(i)).toString();
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
			e.printStackTrace();
		}
		if(value!=null&&!value.equals("")) {
			sql.append(("'"+value+"');"));
		}	
		
		System.out.println(sql.toString());
		
		// 添加执行此sql语句的代码，并且作为返回值
		return 0;
	}

	@Override
	public int update(T t) {
		// update Test set id='12',username='111',password='222' where id=12;
		int id=new MyBeanUtil<T>().getId(t);
		StringBuffer sql = new StringBuffer("update "+t.getClass().getSimpleName()+" set ");
		List<String> all = new MyBeanUtil<>().getFieldName(t);
		int i;
		for(i=0; i<all.size()-1; i++) {
			String value=null;
			try {
				value = BeanUtils.getProperty(t,all.get(i)).toString();
				sql.append(all.get(i)+"='"+value+"',");
			} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
				e.printStackTrace();
			}
		}

		// 添加
		String value=null;
		try {
			value = BeanUtils.getProperty(t,all.get(i)).toString();
			sql.append(all.get(i)+"='"+value+"' where id="+id+";");
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
			e.printStackTrace();
		}
		
		System.out.println(sql.toString());
		// 添加执行此sql语句的代码，并且作为返回值
		return 0;
	}

	@Override
	public T find(T t) {
		int id=new MyBeanUtil<T>().getId(t);
		String sql = "select * from "+t.getClass().getSimpleName() +" where id = "+id;
		
		System.out.println(sql);
		// 添加执行此sql语句的代码，并且作为返回值
		return null;
	}

	@Override
	public int delelte(T t) {
		int id=new MyBeanUtil<T>().getId(t);
		String sql="delete from "+t.getClass().getSimpleName()+" where id = "+id;
		
		System.out.println(sql);
		// 添加执行此sql语句的代码，并且作为返回值
		return 0;
	}

	@Override
	public List<T> getAll(String param)  {
		String sql="select * from "+beanClass.getSimpleName()+" "+param;
		
		System.out.println(sql);
		// 添加执行此sql语句的代码，并且作为返回值
		return null;
	}

	@Override
	public int deleleteAll(String param) {
		String sql="delete from "+beanClass.getSimpleName()+" "+param;
		System.out.println(sql);
		// 添加执行此sql语句的代码，并且作为返回值
		return 0;
	}

}
