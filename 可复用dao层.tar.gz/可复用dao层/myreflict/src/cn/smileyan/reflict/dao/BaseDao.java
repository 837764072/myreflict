package cn.smileyan.reflict.dao;

import java.util.List;

/**
 * 最基本的接口，实现增删改查
 * 特别提醒，id号为int类型。
 * 另外数据库中需要满足的条件在《任务说明》中已经介绍
 * @author smileyan
 */
public interface BaseDao<T> {
	/**
	 * 增加一条数据
	 * @param t 实体类 
	 * @return 添加成功后的ID号
	 */
	int save(T t);
	
	/**
	 * 修改一条数据
	 * @param t
	 * @return 修改成功后的ID号
	 */
	int update(T t);
	
	/**
	 * 查找对象
	 * @param t 根据实体类中的某一个元素进行查找
	 * @return 符合条件的实体类，只返回第一个查到的
	 */
	T find(T t);
	
	/**
	 * 删除某个对象
	 * @param t
	 * @return 删除的对象的实体类
	 */
	int delelte(T t);
	
	/**
	 * 根据param中的条件，返回所有的对象
	 * @param param 比如说 "from User" 即可无条件拿到所有。 
	 * 比如说"from User where id < 50"则是带条件查找。
	 * @return List
	 */
	List<T> getAll(String param);
	
	/**
	 * 删除所有满足param条件的对象
	 * @param param
	 * @return 删除执行状态
	 */
	int deleleteAll(String param);
}
