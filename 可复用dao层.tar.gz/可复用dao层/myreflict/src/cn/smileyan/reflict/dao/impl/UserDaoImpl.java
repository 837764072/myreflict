package cn.smileyan.reflict.dao.impl;

import cn.smileyan.reflict.dao.UserDao;
import cn.smileyan.reflict.domain.User;

public class UserDaoImpl extends BaseDaoImpl<User> implements UserDao {


}
